package javaapplication1;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.UIManager;
import javax.swing.table.JTableHeader;

@SuppressWarnings("serial")
public class Tickets extends JFrame implements ActionListener {

  // class level member objects
  Dao dao = new Dao(); // for CRUD operations
  Boolean chkIfAdmin = false;


  public Tickets(Boolean isAdmin) {
	//create panel for ticket menu
	//create if statement that will determine if an Admin is loggin on.
    if (isAdmin != chkIfAdmin) {
      System.out.println("You are Logged in as Admin.  If you are not admin please logout.");
      //For admins, show the table at start up.  An admin is more focused on tasks at hand than design of GUI.
      try {

        // Use JTable built in functionality to build a table model and
        // display the table model off your result set!!!
        JTable jt = new JTable(ticketsJTable.buildTableModel(dao.readRecords()));
        //set bounds of Jtable
        jt.setBounds(200, 200, 400, 400);
        JScrollPane sp = new JScrollPane(jt);
        //add scroll pane Jtable to first frame.
        add(sp);
        //set bounds of scroll pane Jtable.
        sp.setBounds(200,200,400,400);
        //refreshes or repaints frame on screen
        setVisible(true);
        //verify that ticket has generated.
        System.out.println("Ticket view has generated.");
        chkIfAdmin = true;
        //throw exception and display that ticket view failed to generate.
      } catch (SQLException e1) {
        System.out.println("Ticket failed to generate .");
        e1.printStackTrace();
      }
      //else statement will welcome anyone determined to be a user.
    } else {
      System.out.println("Welcome User Feel free to view and create tickets as you see fit. We are here to help!");
    }

    //set check admin to isAdmin
    chkIfAdmin = isAdmin;
    //launch createMenu
    createMenu();
    //launch prepareGUI
    prepareGUI();

  }

  // Main menu object items
  private JMenu mnuFile = new JMenu("File");
  private JMenu mnuAdmin = new JMenu("Admin");
  private JMenu mnuTickets = new JMenu("Tickets");

  // Sub menu item objects for all Main menu item objects
  JMenuItem mnuItemExit;
  //JMenuItem mnuItemRefresh;
  JMenuItem mnuItemUpdate;
  JMenuItem mnuItemDelete;
  JMenuItem mnuItemOpenTicket;
  JMenuItem mnuItemViewTicket;
  JMenuItem mnuItemSelectTicket;

  private void createMenu() {

    /* Initialize sub menu items **************************************/

    // initialize sub menu item for File main menu
    mnuItemExit = new JMenuItem("Exit");
    // add to File main menu item
    mnuFile.add(mnuItemExit);
    
    //create if statement that will show UPDATE and DELETE tabs if Admins are loggin in.
    if (chkIfAdmin == true) {
      // initialize first sub menu items for Admin main menu
      mnuItemUpdate = new JMenuItem("Update Ticket");
      // add to Admin main menu item
      mnuAdmin.add(mnuItemUpdate);

      // initialize second sub menu items for Admin main menu
      mnuItemDelete = new JMenuItem("Delete Ticket");
      // add to Admin main menu item
      mnuAdmin.add(mnuItemDelete);
    }
    
    //File menu options for users will be SELECT, VIEW, and OPEN ticket.
    // initialize first sub menu item for Tickets main menu
    mnuItemOpenTicket = new JMenuItem("Open Ticket");
    // add to Ticket Main menu item
    mnuTickets.add(mnuItemOpenTicket);

    // initialize second sub menu item for Tickets main menu
    mnuItemViewTicket = new JMenuItem("View Ticket");
    // add to Ticket Main menu item
    mnuTickets.add(mnuItemViewTicket);

    // initialize any more desired sub menu items below
    // initialize third sub menu item for Tickets main menu
    mnuItemSelectTicket = new JMenuItem("Select Ticket");
    // add to Ticket Main menu item
    mnuTickets.add(mnuItemSelectTicket);

    /* Add action listeners for each desired menu item *************/
    mnuItemExit.addActionListener(this);
    
    //add action listeners for UPDATE and DELETE if admin is determined.
    if (chkIfAdmin == true) { //on show these on admin
      mnuItemUpdate.addActionListener(this);
      mnuItemDelete.addActionListener(this);
    }
    
    //Otherwise add action listeners for OPEN, VIEW, and SELECT
    mnuItemOpenTicket.addActionListener(this);
    mnuItemViewTicket.addActionListener(this);
    mnuItemSelectTicket.addActionListener(this);

    /*
     * continue implementing any other desired sub menu items (like 
     * for update and delete sub menus for example) with similar 
     * syntax & logic as shown above*
     */

  }

  private void prepareGUI() {

    // create JMenu bar
    JMenuBar bar = new JMenuBar();
    bar.add(mnuFile); // add main menu items in order, to JMenuBar
    if (chkIfAdmin == true) { //only show this to admin
      bar.add(mnuAdmin);
    }
    bar.add(mnuTickets);
    // add menu bar components to frame
    setJMenuBar(bar);

    addWindowListener(new WindowAdapter() {
      // define a window close operation
      public void windowClosing(WindowEvent wE) {
        System.exit(0);
      }
    });
    // set frame options
    setSize(1000, 450);
    //centers frame
    setLocationRelativeTo(null);
    setVisible(true);
    //for users, the ticket menu will have IIT colors.
    
    //configure layout for frame to BorderLayout
    setLayout(new BorderLayout());
    
  	//create icon for ticket menu
  	ImageIcon logo1 = new ImageIcon("iit_logo.png");
  	//create panel for ticket menu gray border
  	JPanel pn1 = new JPanel();
  	JPanel pn2 = new JPanel();
  	//create panel for ticket menu gray border
  	JPanel pn3 = new JPanel();
  	//create panel for ticket menu gray border
  	JPanel pn4 = new JPanel();
  	//create panel for ticket menu gray border
  	JPanel pn5 = new JPanel();
   
  	//change icon of frame
  	setIconImage(logo1.getImage());
  	
  	//configure color for background of ticket page, custom shade of white
  	Color c1 = new Color(251,255,253);
  	//set custom shade of white to the background of ticket page
  	pn1.setBackground(c1);
  	//configure another color for all buttons of ticket page, custom shade of red
  	Color c2 = new Color(230,24,55);
  	//set custom shade of red to all buttons on ticket page
  	
  	//set size of border pn2
  	pn2.setPreferredSize( new Dimension(20,20));
  	//set size of border pn3 
  	pn3.setPreferredSize(new Dimension(20,20));
  	//set size of border pn4
  	pn4.setPreferredSize(new Dimension(20,20));
  	//set size of border pn5
  	pn5.setPreferredSize(new Dimension(20,20));
  	
  	//set background of border pn2 to custom red
  	pn2.setBackground(c2);
  	//set background of border pn3 to gray
  	pn3.setBackground(Color.GRAY);
  	//set background of border pn4 to gray
  	pn4.setBackground(Color.GRAY);
  	//set background of border pn5 to custom red
  	pn5.setBackground(c2);

  	
  	//add panel to ticket menu frame
  	add(pn1);
  	//add border pn2 to NORTH of frame
  	add(pn2,BorderLayout.NORTH);
  	//add border pn3 to WEST of frame
  	add(pn3,BorderLayout.WEST);
  	//add border pn4 to EAST of frame
  	add(pn4,BorderLayout.EAST);
  	//add border pn5 to SOUTH of frame
  	add(pn5,BorderLayout.SOUTH);
  	//remove white background when view so that it does not block out table
  	pn1.setVisible(false);
  }

  @Override
  public void actionPerformed(ActionEvent e) {
    //implement actions for sub menu items
    if (e.getSource() == mnuItemExit) {
      System.out.println("You have exited Ticket System.");
      System.exit(0);
    } else if (e.getSource() == mnuItemOpenTicket) {

      //prompt user for ticket information
      String ticketName = JOptionPane.showInputDialog(null, "Please Enter your name");
      String ticketDesc = JOptionPane.showInputDialog(null, "Please Enter a ticket description");
      
      //create if statement that will let the user know that the ticket creation failed due to not entering name or description of problem
      if (ticketName == null || (ticketName != null && ("".equals(ticketName))) || ticketDesc == null || (ticketDesc != null && ("".equals(ticketDesc)))) {
        JOptionPane.showMessageDialog(null, "Ticket generate error: Missing name OR Missing description");
        System.out.println("Ticket generate error: Missing name OR Missing description");
      } else {
        //ticket data inserts into database
        int id = dao.insertRecords(ticketName, ticketDesc);

        //display whether ticket has been created to console OR through dialog box.
        if (id != 0) {
          System.out.println("Ticket ID : " + id + " generated successfully.");
          JOptionPane.showMessageDialog(null, "Ticket id: " + id + " generated successfully");

          try {

            // Use JTable built in functionality to build a table model and
            // display the table model off your result set!!!
            JTable jt = new JTable(ticketsJTable.buildTableModel(dao.readRecords()));
            jt.setBounds(30, 40, 200, 400);
            JScrollPane sp = new JScrollPane(jt);
            add(sp);
            //refreshes or repaints frame on screen
            setVisible(true); 
            //confirm that ticket has generated.
            System.out.println("Ticket view generated.");
          } catch (SQLException e1) {
            System.out.println("Ticket view failed to generate.");
            e1.printStackTrace();
          }
        } else
          //confirm that ticket failed to generate
          System.out.println("Ticket failed to generate.");
      }
    } else if (e.getSource() == mnuItemViewTicket) {

      // retrieve all tickets details for VIEW of JTable
      try {

        // Use JTable built in functionality to build a table model and
        // display the table model off your result set!!!
        JTable jt = new JTable(ticketsJTable.buildTableModel(dao.readRecords()));
        //create second frame. When user clicks VIEW ticket, the ticket will appear on new frame.
        JFrame f2 = new JFrame("View Ticket(s)");
        jt.setBounds(30, 40, 200, 400);
        JScrollPane sp = new JScrollPane(jt);
        //add Jtable to second frame titled "View Ticket(s)"
        f2.add(sp);
        f2.setSize(550,550);
        //create logo1 variable, file iit_logo.png
        ImageIcon logo1 = new ImageIcon("iit_logo.png");
        //set iit logo as second frame image
        f2.setIconImage(logo1.getImage());
        //set second frame to visible so Selected Window frame will appear
        f2.setVisible(true);
        //refreshes or repaints frame on screen
        setVisible(true); 
        System.out.println("Ticket view has generated.");
      } catch (SQLException e1) {
        System.out.println("Ticket view failed to generate.");
        e1.printStackTrace();
      }
    }
    //select specific ticket to view
    else if (e.getSource() == mnuItemSelectTicket) {

      String ticketId = JOptionPane.showInputDialog(null, "Enter the ticket ID: ");

      //create if statement that will let user know of error when they do not put a ticket ID for select statement.
      if (ticketId == null || (ticketId != null && ("".equals(ticketId)))) {
    	//send ID error message to console and dialog box
        JOptionPane.showMessageDialog(null, "Ticket select has failed to generate: missing ID.");
        System.out.println("Ticket select has failed to generate: missing ID.");
      } else {
        // retrieve tickets details for SELECT statement in JTable
        int tid = Integer.parseInt(ticketId);
        try {

          // Use JTable built in functionality to build a table model and
          // display the table model off your result set!!!
          JTable jt = new JTable(ticketsJTable.buildTableModel(dao.viewRecords(tid)));
          //create third frame. When user clicks select ticket, the ticket will appear on new frame.
          JFrame f3 = new JFrame("Selected Ticket");
          jt.setBounds(30, 40, 200, 400);
          JScrollPane sp = new JScrollPane(jt);
          //add jTable to third frame titled "Selected Ticket"
          f3.add(sp);
          //set size of third frame.
          f3.setSize(550,550);
          //create logo1 variable, file iit_logo.png
          ImageIcon logo1 = new ImageIcon("iit_logo.png");
          //set iit logo as third frame image
          f3.setIconImage(logo1.getImage());
          //set third frame to visible so Selected Window frame will appear
          f3.setVisible(true);
          // refreshes or repaints frame on screen
          setVisible(true);
          //let user know whether the ticket select has generated or failed to generate.
          System.out.println("Ticket Select has generated.");
        } catch (SQLException e1) {
          System.out.println("Ticket selet has failed to generate.");
          e1.printStackTrace();
        }
      }
    }
    /*
     * continue implementing any other desired sub menu items (like for update and
     * delete sub menus for example) with similar syntax & logic as shown above
     */
    else if (e.getSource() == mnuItemUpdate) {
      // get ticket information
      String ticketId = JOptionPane.showInputDialog(null, "Enter ticket ID to update");
      String ticketDesc = JOptionPane.showInputDialog(null, "Enter a new description");
      String ticketStatus = JOptionPane.showInputDialog(null, "Update the ticket status");

      if (ticketId == null || (ticketId != null && ("".equals(ticketId))) || ticketStatus == null || (ticketStatus != null && ("".equals(ticketStatus)))) {
        JOptionPane.showMessageDialog(null, "Ticket update failed: empty id / status.");
        System.out.println("Ticket update failed: empty id / status.");
      } else {
        // insert ticket information to database
        int tid = Integer.parseInt(ticketId);

        //go to dao to update records
        dao.updateRecords(ticketId, ticketDesc, ticketStatus);

        // display results if successful or not to console / dialog box
        if (tid != 0) {
          System.out.println("Ticket ID : " + tid + " updated successfully.");
          JOptionPane.showMessageDialog(null, "Ticket id: " + tid + " updated");
        } else
          System.out.println("Ticket update failed.");

        try {

          // Use JTable built in functionality to build a table model and
          // display the table model off your result set!!!
          JTable jt = new JTable(ticketsJTable.buildTableModel(dao.viewRecords(tid)));
          //create fourth frame. When user clicks update ticket, the ticket will appear on new frame.
          JFrame f4 = new JFrame("Updated Ticket");
          jt.setBounds(30, 40, 200, 400);
          JScrollPane sp = new JScrollPane(jt);
          //add jTable to fourth frame titled "Updated Ticket"
          f4.add(sp);
          //set size of fourth frame.
          f4.setSize(550,550);
          //create logo1 variable, file iit_logo.png
          ImageIcon logo1 = new ImageIcon("iit_logo.png");
          //set iit logo as fourth frame image
          f4.setIconImage(logo1.getImage());
          //set fourth frame to visible so Upated Ticket Window frame will appear
          f4.setVisible(true);
          // refreshes or repaints frame on screen
          setVisible(true);
          System.out.println("Ticket view has generated.");
        } catch (SQLException e1) {
          System.out.println("Ticket view failed to generate.");
          e1.printStackTrace();
        }

      }
    } else if (e.getSource() == mnuItemDelete) {
      // get ticket information
      String ticketId = JOptionPane.showInputDialog(null, "Enter ticket ID that you wish to delete");

      //create if statement that will determin if ticket ID is missing.  Show user the error statement.
      if (ticketId == null || (ticketId != null && ("".equals(ticketId)))) {
        JOptionPane.showMessageDialog(null, "Ticket deletion failed: missing ticket ID.");
        System.out.println("Ticket deletion failed: missing ticket ID.");
      } else {
        // check and compare ticket information from database. want to make sure you are deleting the write one.
        int tid = Integer.parseInt(ticketId);

        //confirm whether user wants to delete ticket.  Ask Yes/No prompt.
        int reply = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete ticket " + tid + "?", "Warning!", JOptionPane.YES_NO_OPTION);
        if (reply == JOptionPane.YES_OPTION) {
          int id = dao.deleteRecords(tid);

          // display results if successful or not to console / dialog bo
          if (id != 0) {
            System.out.println("Ticket ID : " + id + " deleted.");
            JOptionPane.showMessageDialog(null, "Ticket id: " + id + " deleted");
          } else
            System.out.println("Ticket failed deletion!");
        } else {
          JOptionPane.showMessageDialog(null, "Ticket " + tid + " failed to delete.");
        }
      }
    }

  }

}