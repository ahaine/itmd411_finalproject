package javaapplication1;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout; //useful for layouts
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
//controls-label text fields, button
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

@SuppressWarnings("serial")
public class Login extends JFrame implements ActionListener{

  Dao conn;

  public Login() {

    super("IIT HELP DESK LOGIN");
    conn = new Dao();
    conn.createTables();
    conn.addUsers();
    //set size of frame
    setSize(450, 450);
    //set layout of frame to border layout
    setLayout(new BorderLayout());
    setLocationRelativeTo(null); // centers window
   
    //create JPanel for frame
    JPanel pn1 = new JPanel();
    //create logo for login page
    ImageIcon logo1 = new ImageIcon("iit_logo.png");
    //create panel for login page gray border
    JPanel pn2 = new JPanel();
    //create panel for login page gray border
    JPanel pn3 = new JPanel();
    //create panel for login page gray border
    JPanel pn4 = new JPanel();
    //create panel for login page gray border
    JPanel pn5= new JPanel();
    //create username label for login page
    JLabel lb1 = new JLabel("Username:");
    //create textfield for username
    JTextField userN = new JTextField();
    //create password label for login page
    JLabel lb2 = new JLabel("Password:");
    //create textfield for password
    JPasswordField passW = new JPasswordField();
    //create login button for login page
    JButton login = new JButton("Login");
    //create reset button for login page
    JButton reset = new JButton("Reset");
    //create exit Button for login page
    JButton exit = new JButton("Exit");
    //create validation message for password
    JLabel pValidate = new JLabel();
    
    
    //set panel layout to null
    pn1.setLayout(null);
    
    //configure color for background of login page, custom shade of white
    Color c1 = new Color(251,255,253);
    //set custom shade of white to the background of login page
    pn1.setBackground(c1);
    //configure another color for all buttons of login page, custom shade of red
    Color c2 = new Color(230,24,55);
    
    
    //change icon of frame
    setIconImage(logo1.getImage());

    //set size of border pn2
  	pn2.setPreferredSize( new Dimension(20,20));
  	//set size of border pn3 
  	pn3.setPreferredSize(new Dimension(20,20));
  	//set size of border pn4
  	pn4.setPreferredSize(new Dimension(20,20));
  	//set size of border pn5
  	pn5.setPreferredSize(new Dimension(20,20));
  	
  	//set background of border pn2 to custom red
  	pn2.setBackground(c2);
  	//set background of border pn3 to gray
  	pn3.setBackground(Color.GRAY);
  	//set background of border pn4 to gray
  	pn4.setBackground(Color.GRAY);
  	//set background of border pn5 to custom red
  	pn5.setBackground(c2);
  	
  	//set custom shade of red to all buttons of login page
  	login.setBackground(c2);
  	reset.setBackground(c2);
  	exit.setBackground(c2);
  	
  	//set location of username label
  	lb1.setBounds(60,100,75,20);
  	//set location of username textfield
  	userN.setBounds(130,100,200,25);
  	//set location of password label
  	lb2.setBounds(60,130,75,65);
  	//set location of password textfield
  	passW.setBounds(130,150,200,25);
  				
  				
  	//set location of login button
  	login.setBounds(60,200,130,25);
  	//set location of reset button
  	reset.setBounds(200,200,130,25);
  	//set location of exit button
  	exit.setBounds(130,250,130,25);
  	
  	//set focus of login button to false
  	login.setFocusable(false);
  	//set focus of reset button to false
  	reset.setFocusable(false);
  	//set focus of exit button to false
  	exit.setFocusable(false);
  	
  	//set location of password validation message
  	pValidate.setBounds(110, 310, 300, 25);

    //add panels to frame. pn1 is for login page and pn2-pn5 is for background border
    add(pn1);
    add(pn2,BorderLayout.NORTH);
    add(pn3,BorderLayout.WEST);
    add(pn4,BorderLayout.EAST);
    add(pn5,BorderLayout.SOUTH);
   
    //add username label to panel
  	pn1.add(lb1);
  	//add username texfield to panel
  	pn1.add(userN);
  	//add password label to panel
  	pn1.add(lb2);
  	//add password textfield to panel
  	pn1.add(passW);
  	//add login button to panel
  	pn1.add(login);
  	//add reset button to panel
  	pn1.add(reset);
  	//add exit button to panel
  	pn1.add(exit);
  	//add password validation message to panel
  	pn1.add(pValidate);
  	
  	//add actionListener to exit button
  	exit.addActionListener(new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent e) {
			if(e.getSource()==exit) {
				//set exit button to close frame
				dispose();
			}
			
		}
  		
  	});
  	//add actionListener to reset button
  	reset.addActionListener(new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent e) {
			//create reset event that will reset login info
			//create if statement for resetting login credentials
			if(e.getSource()==reset) {
				//reset username
				userN.setText("");
				//reset password
				passW.setText("");
			}
		}
  		
  	});
  	
  	
  	login.addActionListener(new ActionListener() {
      int count = 0; // count agent

      @Override
      public void actionPerformed(ActionEvent e1) {
        boolean admin = false;
        count = count + 1;
        // verify credentials of user

        String query = "SELECT * FROM ahainFP_users WHERE uname = ? and upass = ?;";
        try (PreparedStatement stmt = conn.getConnection().prepareStatement(query)) {
          stmt.setString(1, userN.getText());
          stmt.setString(2, passW.getText());
          ResultSet rs = stmt.executeQuery();
          if (rs.next()) {
            admin = rs.getBoolean("admin"); // get table column value
            new Tickets(admin); //open Tickets file / GUI interface
            setVisible(false); // HIDE THE FRAME
            dispose(); // CLOSE OUT THE WINDOW
          } else
        	//set password validation message color to red
        	pValidate.setForeground(Color.RED);
          	//set validation message to prompt user to try again and show how many attempts are left
            pValidate.setText("Try again! " + (3 - count) + " / 3 attempt(s) left");
        } catch (SQLException ex) {
          ex.printStackTrace();
        }

      }
    });
    
    setVisible(true); // SHOW THE FRAME
  }

  public static void main(String[] args) {

    new Login();
  }

@Override
public void actionPerformed(ActionEvent e) {
	// TODO Auto-generated method stub
	
}
}